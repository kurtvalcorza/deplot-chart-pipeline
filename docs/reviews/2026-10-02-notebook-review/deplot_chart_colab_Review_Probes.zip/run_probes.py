"""Row 19 probes: tutorials/deplot_chart_colab.ipynb at the reviewed commit (232c8e1, blob 90d9093c).

CPU only (CUDA_VISIBLE_DEVICES=-1), install skipped via the notebook's DIMER_NOTEBOOK_CI_PREINSTALLED hook, pinned
build venv holding exactly the notebook PINS (torch 2.14.0, transformers 4.57.6, safetensors 0.8.0, numpy 2.5.3,
pillow 11.3.0, huggingface-hub 0.36.2, pyarrow 25.0.1). The 8 snapshot files are hard-linked from a local copy into
<workdir>/weights/deplot; cell 11 writes the manifest fresh, stage_missing_files finds nothing missing and
verify_snapshot re-hashes every file. The 516 MB SynthChartNet shard is NOT downloaded: Section 4's default branch is
not executed. Stand-in charts drawn with PIL replace the corpus where a dataset is needed (labelled as such).
google.colab.files.upload is replaced by a shim for the BYOD probes except where a probe removes it on purpose.

Probes
  S   static checks (cells, compile, metadata, guided markers, install pattern, carried-module digests)
  P1  cells 3, 5, 7, 9, 11 executed (install skipped) -> real pipeline on CPU
  P2  cell 15 (drawn chart, inference contract) executed on the real model; wall time
  P3  CPU cost of one extraction at 24 and at 2 threads, and of one adaptation step (batch 4), real model;
      extrapolated to the default path's operation count (estimate, labelled)
  P4  re-run semantics on a tiny random Pix2Struct (the repository's test builder): adapt twice as a learner
      re-running cell 19 would; epoch-0 note, evaluate()['adapted'] before the 2nd run, export + fresh reload parity
  P5  BYOD branch of cell 13 through the upload shim: accepted and refused zips; no-google.colab case;
      test-split ceiling at BYOD scale
Usage: python run_probes.py <worktree> <weights_src> <workdir>
"""
import contextlib
import hashlib
import io
import json
import os
import platform
import re
import shutil
import sys
import time
import traceback
import types
import zipfile
from pathlib import Path

os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"
os.environ["HF_HUB_OFFLINE"] = "1"

WT, WSRC, WORK = (Path(a).resolve() for a in sys.argv[1:4])
NB = WT / "tutorials" / "deplot_chart_colab.ipynb"
RESULTS = {"env": {}, "static": {}, "cells": [], "probes": {}}
OUT = Path(__file__).with_name("results.json")
T0 = time.time()


def save():
    OUT.write_text(json.dumps(RESULTS, indent=2, default=str), encoding="utf-8")


nb = json.loads(NB.read_text(encoding="utf-8"))
cells = nb["cells"]


def src(i):
    return "".join(cells[i]["source"])


code_idx = [i for i, c in enumerate(cells) if c["cell_type"] == "code"]

# ------------------------------------------------------------------ static
st = RESULTS["static"]
st["nbformat"] = [nb.get("nbformat"), nb.get("nbformat_minor")]
st["n_cells"], st["n_code"], st["code_idx"] = len(cells), len(code_idx), code_idx
st["metadata_dimer"] = nb["metadata"].get("dimer")
st["outputs_present"] = sum(len(c.get("outputs", [])) for c in cells if c["cell_type"] == "code")
st["compile_errors"] = {}
for i in code_idx:
    try:
        compile(src(i), f"cell{i}", "exec")
    except SyntaxError as e:
        st["compile_errors"][i] = str(e)
md = "\n".join(src(i) for i in range(len(cells)) if cells[i]["cell_type"] == "markdown")
alltext = "\n".join(src(i) for i in range(len(cells)))
st["pip_install_in_kernel"] = "'pip', 'install'" in src(3)
st["uses_uv"] = bool(re.search(r"\buv (venv|pip)\b", alltext))
st["restart_instruction_in_cell3"] = "Restart the runtime" in src(3)
st["cellView_form_cells"] = [i for i in code_idx if cells[i]["metadata"].get("cellView") == "form"]
st["guided_markers"] = {k: (k.lower() in md.lower()) for k in [
    "How to use this notebook", "Roadmap", "Glossary", "Check your reasoning", "What to notice",
    "Expected result", "Troubleshooting", "conclusion", "intended learner", "Infrastructure", "Input →",
    "make a prediction", "Before you run"]}
st["look_for_count"] = len(re.findall(r"(?i)look for", md))
st["carried_module_chars"] = {i: len(src(i)) for i in (5, 7, 9)}
st["code_chars_total"] = sum(len(src(i)) for i in code_idx)
st["declared_spec"] = nb["metadata"]["dimer"].get("notebook_spec")
st["byod_uses_files_upload_only"] = "files.upload()" in src(13) and "BYOD_PATH" not in src(13)
st["byod_records_lookup_uses_bare_next"] = "records_file = next(p for p in" in src(13)
st["byod_flattens_member_names"] = "Path(member.filename).name" in src(13)
st["byod_rerun_instruction"] = "re-run from that cell" in src(0)
st["adapt_cell_builds_fresh_pipeline"] = "from_pretrained" in src(19)
st["reload_assert_has_message"] = bool(re.search(r"assert parity\[[^\n]*,", src(23)))
st["prereq_record_bounds_text"] = re.findall(r"a dataset needs [^;]*", src(1))
st["stated_runtime_minutes_in_notebook"] = re.findall(r"(?i)(\d+\s*(?:min|minutes|hours|h)\b)", md)
mods = {5: "pipeline.py", 7: "metrics.py", 9: "samples.py"}
st["carried_modules"] = {}
for i, name in mods.items():
    meta = cells[i]["metadata"].get("dimer", {})
    st["carried_modules"][name] = {
        "cell_sha256": hashlib.sha256(src(i).encode("utf-8")).hexdigest(),
        "metadata_module_sha256": meta.get("module_sha256"),
        "repo_file_sha256": hashlib.sha256(
            (WT / "src" / "deplot_chart_pipeline" / name).read_bytes().replace(b"\r\n", b"\n")).hexdigest(),
    }
save()

# ------------------------------------------------------------------ environment
WORK.mkdir(parents=True, exist_ok=True)
os.chdir(WORK)
wdir = WORK / "weights" / "deplot"
wdir.mkdir(parents=True, exist_ok=True)
for f in WSRC.iterdir():
    if f.name == "dimer-base-manifest.json" or not f.is_file():
        continue
    dst = wdir / f.name
    if not dst.exists():
        os.link(f, dst)
import torch  # noqa: E402

RESULTS["env"] = {"python": platform.python_version(), "torch": torch.__version__, "cuda": torch.cuda.is_available(),
                  "threads": torch.get_num_threads(), "executable": sys.executable, "platform": platform.platform()}
save()

NS = {"__name__": "__main__"}


def run_cell(i, label=None, ns=NS):
    t = time.time()
    buf = io.StringIO()
    rec = {"cell": i, "label": label}
    try:
        with contextlib.redirect_stdout(buf):
            exec(compile(src(i), f"cell{i}", "exec"), ns)
        rec["ok"] = True
    except BaseException as e:  # noqa: BLE001
        rec["ok"] = False
        rec["error"] = f"{type(e).__name__}: {e}"[:600]
    rec["seconds"] = round(time.time() - t, 1)
    rec["stdout"] = buf.getvalue()[-2500:]
    RESULTS["cells"].append(rec)
    save()
    return rec


# ------------------------------------------------------------------ PART 2 (second invocation, `part2` arg)
# P4b: re-run semantics with selection that actually keeps a trained epoch (no validation split -> final epoch),
#      because on the tiny random model validation cell accuracy is 0 at every epoch and run 1 kept epoch 0.
# P5k: smallest BYOD dataset that passes cell 13 (every split is re-validated with the 8-record minimum).
if len(sys.argv) > 4 and sys.argv[4] == "part2":
    RESULTS = json.loads(OUT.read_text(encoding="utf-8"))
    for i in (5, 7, 9):
        exec(compile(src(i), f"cell{i}", "exec"), NS)
    from PIL import Image, ImageDraw
    from transformers import Pix2StructConfig, Pix2StructForConditionalGeneration, Pix2StructProcessor
    fmt = NS["format_table"]
    d2 = WORK / "part2"
    d2.mkdir(exist_ok=True)
    recs = []
    for i in range(60):
        img = Image.new("RGB", (64, 48), "white")
        ImageDraw.Draw(img).rectangle([4, 40 - (i % 30), 20, 40], fill=(i * 4 % 256, 80, 160))
        pth = d2 / f"{i}.png"
        img.save(pth)
        recs.append({"id": f"r{i:02d}", "image": str(pth), "chart_type": "bar",
                     "target_text": fmt([["A", str(i)], ["B", str(60 - i)]])})

    def tiny(seed=0):
        processor = Pix2StructProcessor.from_pretrained(str(wdir), local_files_only=True)
        processor.image_processor.max_patches = 64
        config = Pix2StructConfig.from_pretrained(str(wdir), local_files_only=True)
        text, vision = config.text_config, config.vision_config
        text.hidden_size, text.d_kv, text.num_heads, text.d_ff, text.num_layers = 32, 8, 4, 64, 3
        vision.hidden_size, vision.d_kv, vision.num_attention_heads, vision.d_ff = 32, 8, 4, 64
        vision.num_hidden_layers = 2
        config.text_config, config.vision_config = text, vision
        torch.manual_seed(seed)
        return NS["DePlotPipeline"]._from_model(Pix2StructForConditionalGeneration(config), processor, "cpu", "tiny")

    p4b = {}
    train, test = recs[:10], recs[10:14]
    base = {k: v.clone() for k, v in tiny()._model.state_dict().items()}
    tp = tiny()
    h = []
    tp.adapt(train, None, epochs=2, lr=1e-3, batch_size=4, trainable_decoder_layers=2,
             progress=lambda e: h.append(("run1", e["epoch"], e.get("note"))))
    after1 = {k: v.clone() for k, v in tp._model.state_dict().items()}
    l1 = [k for k in after1 if k.startswith("decoder.layer.1.")]
    p4b["run1_changed_layer_n_minus_2"] = any(not torch.equal(after1[k], base[k]) for k in l1)
    p4b["evaluate_after_run1_reports_adapted"] = tp.evaluate(test, max_new_tokens=16)["adapted"]
    tp.adapt(train, None, epochs=2, lr=1e-3, batch_size=4, trainable_decoder_layers=1,
             progress=lambda e: h.append(("run2", e["epoch"], e.get("note"))))
    now = tp._model.state_dict()
    p4b["history"] = h
    p4b["run2_started_from_run1_state_layer_n_minus_2_kept"] = all(torch.equal(now[k], after1[k]) for k in l1)
    art = WORK / "p4b_artifact"
    shutil.rmtree(art, ignore_errors=True)
    tp.save_artifact(art)
    fresh = tiny()
    fresh.load_artifact(art)
    fs = fresh._model.state_dict()
    p4b["artifact_tensor_blocks"] = sorted({k.split(".")[2] for k in json.loads((art / "manifest.json").read_text())["tensors"] if k.startswith("decoder.layer.")})
    p4b["reloaded_layer_n_minus_2_equals_in_memory"] = all(torch.equal(fs[k], now[k]) for k in l1)
    p4b["reloaded_layer_n_minus_2_equals_base"] = all(torch.equal(fs[k], base[k]) for k in l1)
    p4b["max_abs_diff_layer_n_minus_2_inmemory_vs_reloaded"] = max(float((fs[k] - now[k]).abs().max()) for k in l1)
    a = [r["text"] for r in tp.predict(test, max_new_tokens=16)]
    b = [r["text"] for r in fresh.predict(test, max_new_tokens=16)]
    p4b["reload_parity_tables"] = {"identical": sum(x == y for x, y in zip(a, b)), "of": len(a)}
    p4b["note"] = "tiny random Pix2Struct, no validation split so the final epoch is kept; lr 1e-3; semantics only"
    RESULTS["probes"]["P4b_rerun_semantics_trained_state"] = p4b
    save()
    mins = {}
    for n in (12, 30, 38, 40, 49, 50, 51, 52):
        try:
            sp = NS["split_dataset"](recs[:n], seed=42)
            for name, part in sp.items():
                NS["validate_dataset"](part)  # what cell 13 does to every split
            mins[n] = {"ok": True, "splits": {k: len(v) for k, v in sp.items()}}
        except ValueError as e:
            mins[n] = {"ok": False, "error": str(e)}
    RESULTS["probes"]["P5k_byod_min_records_cell13"] = mins
    save()
    print("part2 done")
    raise SystemExit(0)

# ------------------------------------------------------------------ P1: setup cells on the real model
for i in (3, 5, 7, 9, 11):
    r = run_cell(i)
    if not r["ok"]:
        raise SystemExit(f"cell {i} failed: {r['error']}")

# ------------------------------------------------------------------ P2: Section 5 drawn chart
NS["Path"] = Path
os.makedirs("outputs", exist_ok=True)
r = run_cell(15, "drawn chart, frozen model")
RESULTS["probes"]["P2_drawn_chart"] = {
    "ok": r["ok"], "seconds": r["seconds"],
    "text": NS.get("result", {}).get("text") if r["ok"] else None,
    "new_tokens": NS.get("result", {}).get("new_tokens") if r["ok"] else None,
    "cell_accuracy": NS["frozen_drawn"]["metrics"][0]["value"] if r["ok"] else None,
    "title_match": NS["frozen_drawn"]["metrics"][1]["value"] if r["ok"] else None,
}
save()

# ------------------------------------------------------------------ stand-in charts (PIL)
from PIL import Image, ImageDraw  # noqa: E402

pipe = NS["pipe"]
format_table = NS["format_table"]
charts = WORK / "standin"
charts.mkdir(exist_ok=True)
LABELS = ["North", "South", "East", "West", "Central", "Islands"]


def draw(path, values, size=(640, 420)):
    img = Image.new("RGB", size, "white")
    d = ImageDraw.Draw(img)
    d.line([(40, 20), (40, size[1] - 40), (size[0] - 10, size[1] - 40)], fill="black", width=2)
    for k, v in enumerate(values):
        x0 = 60 + 95 * k
        top = size[1] - 40 - 3 * v
        d.rectangle([x0, top, x0 + 50, size[1] - 41], fill=(60, 110, 200))
        d.text((x0 + 12, top - 14), str(v), fill="black")
        d.text((x0 + 4, size[1] - 32), LABELS[k], fill="black")
    img.save(path, format="PNG")


standin = []
for i in range(16):
    vals = [10 + (7 * i + 13 * k) % 90 for k in range(6)]
    p = charts / f"c{i:02d}.png"
    draw(p, vals)
    standin.append({"id": f"s{i:02d}", "image_id": f"s{i:02d}", "image": str(p), "chart_type": "bar",
                    "target_text": format_table([[LABELS[k], str(v)] for k, v in enumerate(vals)])})

# ------------------------------------------------------------------ P3: CPU cost, real model
p3 = {}
try:
    rec = NS["validate_dataset"](standin[:4], min_records=1)["records"]
    for threads in (24, 2):
        torch.set_num_threads(threads)
        t = time.time()
        outs = pipe.predict(rec[:2], max_new_tokens=512)
        dt = time.time() - t
        toks = [o["new_tokens"] for o in outs]
        p3[f"extract_threads_{threads}"] = {"charts": 2, "seconds": round(dt, 1), "new_tokens": toks,
                                            "s_per_chart": round(dt / 2, 1),
                                            "s_per_token": round(dt / max(1, sum(toks)), 3)}
        save()
    torch.set_num_threads(24)
    # one adaptation step at batch 4 (train 8 records, 1 epoch -> 2 steps; no validation split)
    t = time.time()
    res = pipe.adapt(NS["validate_dataset"](standin[:8])["records"], None, epochs=1, lr=1e-5, batch_size=4,
                     trainable_decoder_layers=2)
    dt = time.time() - t
    p3["adapt_1epoch_8charts_batch4_threads24"] = {"seconds": round(dt, 1), "steps": 2,
                                                   "s_per_step": round(dt / 2, 1),
                                                   "n_trainable": res["n_trainable"], "n_total": res["n_total"]}
    ops = {"extractions": 160 + 80 * 4 + 160 + 80 + 1 + 1 + 16, "training_steps": (360 // 4) * 3}
    p3["default_path_operation_count"] = ops
    e24 = p3["extract_threads_24"]["s_per_chart"]
    e2 = p3["extract_threads_2"]["s_per_chart"]
    s24 = p3["adapt_1epoch_8charts_batch4_threads24"]["s_per_step"]
    p3["estimate_hours_lower_bound_24_threads"] = round((ops["extractions"] * e24 + ops["training_steps"] * s24) / 3600, 1)
    p3["estimate_hours_lower_bound_2_threads_extractions_only"] = round(ops["extractions"] * e2 / 3600, 1)
    p3["note"] = ("ESTIMATE, not a measurement of the notebook: stand-in charts generate short tables; SynthChartNet "
                  "tables are longer (truncation 5% at 512 tokens on T4), so these are lower bounds. 2-thread figure "
                  "approximates a 2-vCPU hosted CPU runtime; training at 2 threads not measured.")
except Exception as e:  # noqa: BLE001
    p3["error"] = f"{type(e).__name__}: {e}"
    p3["trace"] = traceback.format_exc()[-1500:]
RESULTS["probes"]["P3_cpu_cost"] = p3
save()
del pipe
NS.pop("pipe", None)
import gc  # noqa: E402

gc.collect()

# ------------------------------------------------------------------ P4: re-run semantics, tiny random model
p4 = {}
try:
    from transformers import Pix2StructConfig, Pix2StructForConditionalGeneration, Pix2StructProcessor

    def tiny(seed=0):
        processor = Pix2StructProcessor.from_pretrained(str(wdir), local_files_only=True)
        processor.image_processor.max_patches = 64
        config = Pix2StructConfig.from_pretrained(str(wdir), local_files_only=True)
        text, vision = config.text_config, config.vision_config
        text.hidden_size, text.d_kv, text.num_heads, text.d_ff, text.num_layers = 32, 8, 4, 64, 3
        vision.hidden_size, vision.d_kv, vision.num_attention_heads, vision.d_ff = 32, 8, 4, 64
        vision.num_hidden_layers = 2
        config.text_config, config.vision_config = text, vision
        torch.manual_seed(seed)
        return NS["DePlotPipeline"]._from_model(Pix2StructForConditionalGeneration(config), processor, "cpu",
                                                "tiny-random")

    rec = NS["validate_dataset"](standin)["records"]
    train, val, test = rec[:10], rec[10:13], rec[13:16]
    base_state = {k: v.clone() for k, v in tiny()._model.state_dict().items()}
    tp = tiny()
    hist = []
    r1 = tp.adapt(train, val, epochs=2, lr=1e-3, batch_size=4, trainable_decoder_layers=2,
                  progress=lambda e: hist.append(("run1", e["epoch"], e.get("note"),
                                                  None if not e["val"] else e["val"]["cell_accuracy"])))
    # learner re-runs Section 6's evaluate (BYOD "re-run from that cell") -> is it the frozen model?
    ev = tp.evaluate(test, max_new_tokens=24)
    p4["evaluate_after_first_adapt_reports_adapted"] = ev["adapted"]
    # learner edits TRAINABLE_DECODER_LAYERS=1 and re-runs cell 19 only
    r2 = tp.adapt(train, val, epochs=2, lr=1e-3, batch_size=4, trainable_decoder_layers=1,
                  progress=lambda e: hist.append(("run2", e["epoch"], e.get("note"),
                                                  None if not e["val"] else e["val"]["cell_accuracy"])))
    p4["history"] = hist
    p4["run1"] = {"n_trainable": r1["n_trainable"], "best_epoch": r1["best_epoch"]}
    p4["run2"] = {"n_trainable": r2["n_trainable"], "best_epoch": r2["best_epoch"]}
    st_now = tp._model.state_dict()
    layer1_keys = [k for k in st_now if k.startswith("decoder.layer.1.")]
    p4["layer_n_minus_2_differs_from_base_after_run2"] = any(
        not torch.equal(st_now[k], base_state[k]) for k in layer1_keys)
    art = WORK / "p4_artifact"
    shutil.rmtree(art, ignore_errors=True)
    tp.save_artifact(art)
    man = json.loads((art / "manifest.json").read_text(encoding="utf-8"))
    p4["artifact_tensors"] = man["tensors"]
    fresh = tiny()
    fresh.load_artifact(art)
    fs = fresh._model.state_dict()
    p4["reloaded_state_equal_in_memory"] = all(torch.equal(fs[k], st_now[k]) for k in st_now)
    p4["reloaded_layer_n_minus_2_equal_in_memory"] = all(torch.equal(fs[k], st_now[k]) for k in layer1_keys)
    before = [r["text"] for r in tp.predict(test, max_new_tokens=24)]
    after = [r["text"] for r in fresh.predict(test, max_new_tokens=24)]
    p4["reload_parity_tables"] = {"identical": sum(a == b for a, b in zip(before, after)), "of": len(before)}
    p4["note"] = ("tiny random Pix2Struct (3 decoder layers; 'n-2' = decoder.layer.1, the block a 2-layer run trains "
                  "and a 1-layer run does not); lr 1e-3 so state changes are visible; semantics, not quality")
except Exception as e:  # noqa: BLE001
    p4["error"] = f"{type(e).__name__}: {e}"
    p4["trace"] = traceback.format_exc()[-2000:]
RESULTS["probes"]["P4_rerun_semantics"] = p4
save()

# ------------------------------------------------------------------ P5: BYOD branch of cell 13
p5 = {}
cell13 = src(13)
byod_src = cell13.split("else:\n    shard_path")[0]  # BYOD branch + header; default branch needs the 516 MB shard
byod_src = byod_src.replace("if USE_BYOD:", "if True:")
post = cell13.split("    data_source = f'{CORPUS_NAME}")[1].split("\n", 1)[1]  # validate/split/write/print/probes


def make_zip(entries):
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as z:
        for name, data in entries:
            z.writestr(name, data)
    return b.getvalue()


def png_bytes(path):
    return Path(path).read_bytes()


def recs_jsonl(n, image_fmt="{i}.png", long_target=False):
    lines = []
    for i in range(n):
        tgt = standin[i % 16]["target_text"] if not long_target else "TITLE | " + " <0x0A> ".join(
            f"row{k} | {k}" for k in range(80))
        lines.append(json.dumps({"id": f"b{i:03d}", "image": image_fmt.format(i=i), "target_text": tgt,
                                 "chart_type": "bar"}))
    return "\n".join(lines).encode()


def byod_case(name, payload, *, colab=True):
    shutil.rmtree(WORK / "work", ignore_errors=True)
    ns = dict(NS)
    if colab:
        fake = types.ModuleType("google.colab")
        fake.files = types.SimpleNamespace(upload=lambda: {"byod.zip": payload})
        sys.modules["google"] = types.ModuleType("google")
        sys.modules["google.colab"] = fake
    else:
        sys.modules.pop("google.colab", None)
        sys.modules.pop("google", None)
    t = time.time()
    buf = io.StringIO()
    out = {}
    try:
        with contextlib.redirect_stdout(buf):
            exec(compile("import collections, io, json, zipfile\nfrom pathlib import Path\nSPLIT_SEED = 42\n"
                         + byod_src + "\n" + post, f"cell13_byod_{name}", "exec"), ns)
        out["ok"] = True
        out["splits"] = {k: len(v) for k, v in ns["splits"].items()}
    except BaseException as e:  # noqa: BLE001
        out["ok"] = False
        out["error"] = f"{type(e).__name__}: {e}"[:400]
    out["seconds"] = round(time.time() - t, 2)
    out["stdout_tail"] = buf.getvalue()[-600:]
    p5[name] = out
    save()
    return ns


imgs = [(f"{i}.png", png_bytes(standin[i % 16]["image"])) for i in range(12)]
byod_case("a_12_records_ok", make_zip([("records.jsonl", recs_jsonl(12)), *imgs]))
byod_case("b_8_records_meets_stated_minimum", make_zip([("records.jsonl", recs_jsonl(8)), *imgs[:8]]))
byod_case("c_no_records_file", make_zip(imgs))
byod_case("d_images_in_subfolder_referenced_by_path",
          make_zip([("records.jsonl", recs_jsonl(12, "images/{i}.png")), *[("images/" + n, d) for n, d in imgs]]))
byod_case("e_traversal_member_name", make_zip([("records.jsonl", recs_jsonl(12)), ("../../evil.png", imgs[0][1]),
                                               *imgs]))
byod_case("f_target_over_512_chars", make_zip([("records.jsonl", recs_jsonl(12, long_target=True)), *imgs]))
byod_case("g_not_a_zip", b"this is not a zip archive")
byod_case("h_no_google_colab_runtime", make_zip([("records.jsonl", recs_jsonl(12)), *imgs]), colab=False)
p5["h_traversal_wrote_outside"] = (WORK / "evil.png").exists() or (WORK.parent / "evil.png").exists()

# test-split ceiling at BYOD scale: 2,600 records -> test 520 > MAX_EVAL_RECORDS 500
try:
    big = WORK / "big"
    big.mkdir(exist_ok=True)
    recs = []
    for i in range(2600):
        p = big / f"{i}.png"
        if not p.exists():
            Image.new("RGB", (32, 32), ((i * 7) % 256, (i * 13) % 256, (i // 256) % 256)).save(p)
        recs.append({"id": f"g{i:04d}", "image": str(p), "target_text": "TITLE |  <0x0A> a | 1", "chart_type": "bar"})
    splits = NS["split_dataset"](recs, seed=42)
    sizes = {k: len(v) for k, v in splits.items()}
    try:
        NS["validate_dataset"](splits["test"], min_records=1, max_records=NS["MAX_EVAL_RECORDS"])
        msg = "accepted"
    except ValueError as e:
        msg = f"ValueError: {e}"
    p5["i_2600_records_eval_ceiling"] = {"splits": sizes, "stated_bound": "8..5,000",
                                         "MAX_EVAL_RECORDS": NS["MAX_EVAL_RECORDS"],
                                         "section6_pipe_evaluate_validation": msg}
except Exception as e:  # noqa: BLE001
    p5["i_2600_records_eval_ceiling"] = {"error": f"{type(e).__name__}: {e}"}
# minimum record count that survives split_dataset
mins = {}
for n in range(8, 16):
    try:
        NS["split_dataset"](recs[:n], seed=42)
        mins[n] = "ok"
    except ValueError as e:
        mins[n] = str(e)
p5["j_min_records_for_split"] = mins
RESULTS["probes"]["P5_byod"] = p5
RESULTS["wall_seconds"] = round(time.time() - T0, 1)
save()
print("done", RESULTS["wall_seconds"])
